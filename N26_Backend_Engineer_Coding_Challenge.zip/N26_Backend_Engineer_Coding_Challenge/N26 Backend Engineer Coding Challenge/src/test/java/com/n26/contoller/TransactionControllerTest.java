package com.n26.contoller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.n26.model.Statics;
import com.n26.model.Transaction;
import com.n26.service.TransactionServcie;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class TransactionControllerTest {
	@Autowired
	private TestRestTemplate restTemplate;
	@Autowired
	private TransactionServcie transactionServcie;

	@LocalServerPort
	int randomServerPort;

	@Before
	public void before() {
		transactionServcie.deleteAll();
	}

	@Test
	public void testCreateTransactionForValidData() throws JSONException, URISyntaxException {
		Instant instant1 = Instant.now();
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String valiTimeStamp = formatter.format(instant1);
		valiTimeStamp = valiTimeStamp + "Z";

		final String baseUrl = "http://localhost:" + randomServerPort + "/transactions";
		URI uri = new URI(baseUrl);

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		JSONObject transactionJsonObject = new JSONObject();
		transactionJsonObject.put("amount", "124");
		transactionJsonObject.put("timestamp", valiTimeStamp);

		HttpEntity<String> request = new HttpEntity<String>(transactionJsonObject.toString(), headers);

		assertEquals(HttpStatus.CREATED, restTemplate.postForEntity(uri, request, Object.class).getStatusCode());
	}

	@Test
	public void testCreateTransactionForNotValidDateTime() throws JSONException, URISyntaxException {
		long offset = -70000;
		Instant instant1 = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String valiTimeStamp = formatter.format(instant1);
		valiTimeStamp = valiTimeStamp + "Z";

		final String baseUrl = "http://localhost:" + randomServerPort + "/transactions";
		URI uri = new URI(baseUrl);

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		JSONObject transactionJsonObject = new JSONObject();
		transactionJsonObject.put("amount", "124");
		transactionJsonObject.put("timestamp", valiTimeStamp);

		HttpEntity<String> request = new HttpEntity<String>(transactionJsonObject.toString(), headers);

		assertEquals(HttpStatus.NO_CONTENT, restTemplate.postForEntity(uri, request, Object.class).getStatusCode());
	}

	@Test
	public void testgetStatics() throws URISyntaxException {
		long offset = -30001;
		Instant instant = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String timeStamp = formatter.format(instant);
		timeStamp = timeStamp + "Z";
		Transaction t1 = new Transaction("5", timeStamp);
		Transaction t2 = new Transaction("3", timeStamp);
		Transaction t3 = new Transaction("3", timeStamp);
		transactionServcie.saveNewTransaction(t1);
		transactionServcie.saveNewTransaction(t2);
		transactionServcie.saveNewTransaction(t3);
		final String baseUrl = "http://localhost:" + randomServerPort + "/statistics";
		URI uri = new URI(baseUrl);
		Statics s = restTemplate.getForEntity(uri, Statics.class).getBody();
		assertTrue(s.getMax().toString().equals("5.00"));
		assertTrue(s.getSum().toString().equals("11.00"));
		assertTrue(s.getMin().toString().equals("3.00"));
		assertTrue(s.getAvg().toString().equals("3.67"));
		assertTrue(s.getCount().toString().equals("3"));
	}

	@Test
	public void testDeleteController() throws URISyntaxException {
		final String baseUrl = "http://localhost:" + randomServerPort + "/transactions";
		URI uri = new URI(baseUrl);
		restTemplate.delete(uri);
	}

}
