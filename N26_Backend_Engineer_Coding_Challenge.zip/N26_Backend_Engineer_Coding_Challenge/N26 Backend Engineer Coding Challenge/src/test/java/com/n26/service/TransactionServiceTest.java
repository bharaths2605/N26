package com.n26.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.n26.model.Statics;
import com.n26.model.Transaction;

@RunWith(MockitoJUnitRunner.class)
public class TransactionServiceTest {

	@org.mockito.Mock
	private TransactionServcie transactionServcie;

	@Test
	public void testSaveTransaction() {
		long offset = -70000;
		Instant instant = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String timeStamp = formatter.format(instant);
		timeStamp = timeStamp + "Z";
		Transaction t = new Transaction("123.45", timeStamp);
		transactionServcie.saveNewTransaction(t);
		Mockito.verify(transactionServcie, times(1)).saveNewTransaction(t);

	}

	@Test
	public void testGetStatics() {

		transactionServcie.getStatics();
		Mockito.verify(transactionServcie, times(1)).getStatics();
	}

	@Test
	public void testGetStaticsValue() {
		Statics s = new Statics();
		s.setAvg(new BigDecimal("123"));
		Mockito.when(transactionServcie.getStatics()).thenReturn(s);

		Statics s1 = transactionServcie.getStatics();
		assertEquals(s.getAvg(), s1.getAvg());
	}

	@Test
	public void testDeleteAll() {
		transactionServcie.deleteAll();
		Mockito.verify(transactionServcie, times(1)).deleteAll();
	}
}
