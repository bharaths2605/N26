package com.n26.datastore;

import static org.junit.Assert.assertTrue;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.n26.Application;
import com.n26.dataStore.TransactionStore;
import com.n26.exception.TransactionNotValidException;
import com.n26.exception.TransactionTimeNotValidException;
import com.n26.model.Statics;
import com.n26.model.Transaction;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = Application.class)
@WebAppConfiguration
public class TransactionStoreTest {

	@Autowired
	private TransactionStore transactionStore;

	@Before
	public void before() {
		transactionStore.reset();
	}

	@Test
	public void testSaveMethod() {
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		Instant instant = Instant.now();
		String timeStamp = formatter.format(instant);

		Transaction t = new Transaction("123.45", timeStamp);
		transactionStore.save(t);
		assertTrue(transactionStore.getTransactions().size() == 1);
	}

	@Test
	public void testClearMethod() {
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		Instant instant = Instant.now();
		String timeStamp = formatter.format(instant);

		Transaction t = new Transaction("123.45", timeStamp);
		Transaction t1 = new Transaction("156.45", timeStamp);
		Transaction t2 = new Transaction("123.48", timeStamp);
		transactionStore.save(t);
		transactionStore.save(t1);
		transactionStore.save(t2);
		transactionStore.reset();
		assertTrue(transactionStore.getTransactions().size() == 0);

	}

	@Test
	public void testGetTimeOffSetMethodInSeconds() {
		long offset = -60000;
		Instant instant = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String timeStamp = formatter.format(instant);
		timeStamp = timeStamp + "Z";
		Transaction t = new Transaction("123.45", timeStamp);
		long b = transactionStore.getTimeDiffrence(t);
		assertTrue((b / 1000) == 60);

	}

	@Test(expected = TransactionNotValidException.class)
	public void testNotValidTransaction() throws TransactionTimeNotValidException, TransactionNotValidException {
		long offset = -70000;
		Instant instant = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String timeStamp = formatter.format(instant);
		timeStamp = timeStamp + "Z";
		Transaction t = new Transaction("123.45", timeStamp);
		transactionStore.validateTime(t);
	}

	@Test(expected = TransactionTimeNotValidException.class)
	public void testTransactionTimeNotValid() throws TransactionTimeNotValidException, TransactionNotValidException {
		long offset = 600000;
		Instant instant = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String timeStamp = formatter.format(instant);
		timeStamp = timeStamp + "Z";
		Transaction t = new Transaction("123.45", timeStamp);
		transactionStore.validateTime(t);
	}

	@Test(expected = NumberFormatException.class)
	public void testInvalidAmount() {
		Transaction t = new Transaction("test", "2018-07-17T09:59:51.312Z");
		transactionStore.validateAmount(t);
	}

	@Test
	public void testGetStaticsObject() {
		long offset = -30001;
		Instant instant = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String timeStamp = formatter.format(instant);
		timeStamp = timeStamp + "Z";
		Transaction t1 = new Transaction("5", timeStamp);
		Transaction t2 = new Transaction("3", timeStamp);
		Transaction t3 = new Transaction("3", timeStamp);
		transactionStore.save(t1);
		transactionStore.save(t2);
		transactionStore.save(t3);
		Statics s = transactionStore.getStaticsObject();
		assertTrue(s.getMax().toString().equals("5.00"));
		assertTrue(s.getSum().toString().equals("11.00"));
		assertTrue(s.getMin().toString().equals("3.00"));
		assertTrue(s.getAvg().toString().equals("3.67"));
		assertTrue(s.getCount().toString().equals("3"));

	}

	@Test
	public void removeOldTransaction() {
		long offset = -70000;
		Instant instant = Instant.now().plusMillis(offset);
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.from(ZoneOffset.UTC));
		String invalidTimeStamp = formatter.format(instant);
		invalidTimeStamp = invalidTimeStamp + "Z";
		Transaction t1 = new Transaction("5", invalidTimeStamp);
		Transaction t2 = new Transaction("3", invalidTimeStamp);
		Transaction t3 = new Transaction("3", invalidTimeStamp);
		long Validoffset = -50000;
		Instant instant1 = Instant.now().plusMillis(Validoffset);
		String valiTimeStamp = formatter.format(instant1);
		valiTimeStamp = valiTimeStamp + "Z";
		Transaction t4 = new Transaction("3", valiTimeStamp);
		transactionStore.reset();
		transactionStore.save(t1);
		transactionStore.save(t2);
		transactionStore.save(t3);
		transactionStore.save(t4);
		transactionStore.removeOldTransaction();
		assertTrue(transactionStore.getTransactions().size() == 1);
	}

	@After
	public void resetAfter() {
		transactionStore.reset();
	}
}
