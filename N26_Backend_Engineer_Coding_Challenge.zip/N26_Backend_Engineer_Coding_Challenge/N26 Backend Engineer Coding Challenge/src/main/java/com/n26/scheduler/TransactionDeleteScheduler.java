package com.n26.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.n26.constants.TransactionConstants;
import com.n26.dataStore.TransactionStore;

/**
 * @author Bharath
 *
 */
@Component
public class TransactionDeleteScheduler {

	@Autowired
	private TransactionStore transactionStore;

	/**
	 * @throws InterruptedException
	 *             Scheduler to remove old Transaction
	 */
	@Scheduled(fixedRate = TransactionConstants.SCHEDULER_TIME_IN_MILLISECONDS)
	public void fixedRateSch() throws InterruptedException {
		transactionStore.removeOldTransaction();
	}

}
