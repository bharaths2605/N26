package com.n26.dataStore;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.n26.constants.TransactionConstants;
import com.n26.exception.TransactionNotValidException;
import com.n26.exception.TransactionTimeNotValidException;
import com.n26.model.Statics;
import com.n26.model.Transaction;

import lombok.Getter;

/**
 * @author Bharath
 *
 */
@Component()
public class TransactionStore {
	@Getter
	private List<Transaction> transactions = new ArrayList<>();
	private Lock lock = new ReentrantLock();
	private Statics statistics;
	public static final String CLASS_NAME = TransactionStore.class.getName();
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	private void lock() {
		lock.lock();
	}

	private void unLock() {
		lock.unlock();
	}

	/**
	 * @param transaction
	 *            Method to save transaction
	 */
	public synchronized void save(Transaction transaction) {
		lock();
		log.debug(CLASS_NAME + ":Inside save method ");
		transactions.add(transaction);
		unLock();
	}

	/**
	 * Method to delete all transaction
	 */
	public synchronized void reset() {
		lock();
		log.debug(CLASS_NAME + ":Inside reset method ");
		transactions.clear();
		unLock();
	}

	/**
	 * @return Method to find Statics of all Transaction
	 */
	public synchronized Statics getStaticsObject() {
		log.debug(CLASS_NAME + ":Inside getStaticsObject ");
		if (!transactions.isEmpty()) {
			removeOldTransaction();
			if (!transactions.isEmpty()) {
				log.debug("Transactions Statics is calculated");
				DoubleSummaryStatistics stat = transactions.stream().mapToDouble(a -> new Double(a.getAmount()))
						.summaryStatistics();
				return statistics = new Statics(BigDecimal.valueOf(stat.getSum()).setScale(2, RoundingMode.HALF_UP),
						BigDecimal.valueOf(stat.getAverage()).setScale(2, RoundingMode.HALF_UP),
						BigDecimal.valueOf(stat.getMax()).setScale(2, RoundingMode.HALF_UP),
						BigDecimal.valueOf(stat.getMin()).setScale(2, RoundingMode.HALF_UP), stat.getCount());
			}

		}
		log.debug("Transactions list is empty");
		return statistics = new Statics();
	}

	/**
	 * Method to remove old transaction
	 */
	public synchronized void removeOldTransaction() {
		lock();
		log.debug(CLASS_NAME + ":Removing old transactions");
		transactions = transactions.stream().filter(v -> v.getTimestamp() != null)
				.filter(a -> (getTimeDiffrence(a) < TransactionConstants.TRANSACTION_TIME_PERIOD_MILLISECONDS)
						&& (getTimeDiffrence(a) > TransactionConstants.ZERO))
				.collect(Collectors.toList());
		unLock();
	}

	/**
	 * @param transaction
	 * @return
	 * @throws DateTimeParseException
	 *             Method to calculate time difference between transaction time and
	 *             current time
	 */
	public long getTimeDiffrence(Transaction transaction) throws DateTimeParseException {
		log.debug(CLASS_NAME + ":Calculating Time Difference");
		Instant instant = Instant.parse(transaction.getTimestamp());
		Instant instant1 = Instant.now();
		return (instant1.toEpochMilli() - instant.toEpochMilli());
	}

	/**
	 * @param transaction
	 * @throws NumberFormatException
	 *             Method to validate transaction amount
	 */
	public void validateAmount(Transaction transaction) throws NumberFormatException {
		log.debug(CLASS_NAME + ":Validating transaction amount");
		new BigDecimal(transaction.getAmount());
	}

	/**
	 * @param transaction
	 * @throws TransactionTimeNotValidException
	 * @throws TransactionNotValidException
	 * 
	 *             Method to validate transaction time
	 */
	public void validateTime(Transaction transaction)
			throws TransactionTimeNotValidException, TransactionNotValidException {
		log.debug(CLASS_NAME + ":Validating transaction time");
		long diffrence_in_milli_seconds = getTimeDiffrence(transaction);
		if (diffrence_in_milli_seconds > TransactionConstants.TRANSACTION_TIME_PERIOD_MILLISECONDS) {
			log.debug("Transaction time is older than 60 seconds" + transaction.getTimestamp());
			throw new TransactionNotValidException();
		}
		if (diffrence_in_milli_seconds < TransactionConstants.ZERO) {
			log.debug("Transaction time is greater than current time" + transaction.getTimestamp());
			throw new TransactionTimeNotValidException();
		}
	}

}
