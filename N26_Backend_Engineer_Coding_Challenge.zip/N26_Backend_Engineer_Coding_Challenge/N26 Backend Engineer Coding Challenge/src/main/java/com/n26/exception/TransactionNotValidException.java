package com.n26.exception;

/**
 * @author Bharath
 *
 */
public class TransactionNotValidException extends Exception {

}
