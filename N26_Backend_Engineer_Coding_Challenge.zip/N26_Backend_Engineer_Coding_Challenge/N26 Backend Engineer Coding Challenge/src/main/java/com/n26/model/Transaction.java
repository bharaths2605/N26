package com.n26.model;

import javax.validation.constraints.NotNull;

import lombok.Data;

/**
 * @author Bharath
 *
 */
@Data
public class Transaction {

	@NotNull
	private String amount;

	@NotNull
	private String timestamp;

	public Transaction() {
	}

	public Transaction(@NotNull String amount, @NotNull String timestamp) {
		super();
		this.amount = amount;
		this.timestamp = timestamp;
	}

}
