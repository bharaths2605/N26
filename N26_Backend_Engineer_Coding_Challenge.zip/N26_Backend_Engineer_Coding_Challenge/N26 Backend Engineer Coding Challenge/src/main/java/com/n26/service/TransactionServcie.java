package com.n26.service;

import org.springframework.http.ResponseEntity;

import com.n26.model.Statics;
import com.n26.model.Transaction;

/**
 * @author Bharath
 *
 */
public interface TransactionServcie {

	/**
	 * @param transaction
	 * @return Method to save new transaction
	 */
	public ResponseEntity<?> saveNewTransaction(Transaction transaction);

	/**
	 * @return Method to get Transaction Statics
	 */
	public Statics getStatics();

	/**
	 * Method to delete transction
	 */
	public void deleteAll();

}
