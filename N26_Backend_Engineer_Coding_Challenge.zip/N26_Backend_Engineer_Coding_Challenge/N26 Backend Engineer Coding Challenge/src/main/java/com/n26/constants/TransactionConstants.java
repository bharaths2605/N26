package com.n26.constants;

/**
 * @author Bharath
 *
 */
public class TransactionConstants {

	public static final long ZERO = 0;

	/**
	 * Constant to check time diffrence
	 */
	public static final long TRANSACTION_TIME_PERIOD_MILLISECONDS = 60000;

	/**
	 * Constant for scheduler
	 */
	public static final long SCHEDULER_TIME_IN_MILLISECONDS = 10000;
}
