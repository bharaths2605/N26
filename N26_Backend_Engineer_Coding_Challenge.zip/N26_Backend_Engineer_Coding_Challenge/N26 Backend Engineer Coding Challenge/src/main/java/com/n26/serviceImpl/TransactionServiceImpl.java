package com.n26.serviceImpl;

import java.time.format.DateTimeParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.n26.dataStore.TransactionStore;
import com.n26.exception.TransactionNotValidException;
import com.n26.exception.TransactionTimeNotValidException;
import com.n26.model.Statics;
import com.n26.model.Transaction;
import com.n26.service.TransactionServcie;

/**
 * @author Bharath
 *
 */
@Service
public class TransactionServiceImpl implements TransactionServcie {

	public static final String CLASS_NAME = TransactionServiceImpl.class.getName();
	@Autowired
	private TransactionStore transactionStore;

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public ResponseEntity<?> saveNewTransaction(Transaction transaction) {
		try {
			log.debug(CLASS_NAME + ": inside saveNewTransaction");
			transactionStore.validateAmount(transaction);
			transactionStore.validateTime(transaction);
			transactionStore.save(transaction);

		} catch (TransactionTimeNotValidException | DateTimeParseException | NumberFormatException t) {
			if (t instanceof NumberFormatException) {
				log.debug("Transaction Amount is Not Parsable", transaction.getAmount());
			}
			return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(null);
		} catch (TransactionNotValidException e) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
		return ResponseEntity.status(HttpStatus.CREATED).body(null);

	}

	@Override
	public Statics getStatics() {
		log.debug(CLASS_NAME + ": inside getStatics");
		return transactionStore.getStaticsObject();
	}

	@Override
	public void deleteAll() {
		log.debug(CLASS_NAME + ": inside deleteAll");
		transactionStore.reset();
	}

}
