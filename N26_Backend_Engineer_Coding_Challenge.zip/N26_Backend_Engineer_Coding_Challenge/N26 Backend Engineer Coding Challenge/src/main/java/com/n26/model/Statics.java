package com.n26.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

/**
 * @author Bharath
 *
 */
@Data
public class Statics {
	@JsonFormat(shape = JsonFormat.Shape.STRING)
	private BigDecimal sum;
	@JsonFormat(shape = JsonFormat.Shape.STRING)
	private BigDecimal avg;
	@JsonFormat(shape = JsonFormat.Shape.STRING)
	private BigDecimal max;
	@JsonFormat(shape = JsonFormat.Shape.STRING)
	private BigDecimal min;
	private Long count;

	public Statics() {
		sum = BigDecimal.valueOf(0.00).setScale(2, RoundingMode.HALF_UP);
		avg = BigDecimal.valueOf(0.00).setScale(2, RoundingMode.HALF_UP);
		max = BigDecimal.valueOf(0.00).setScale(2, RoundingMode.HALF_UP);
		min = BigDecimal.valueOf(0.00).setScale(2, RoundingMode.HALF_UP);
		count = 0L;
	}

	public Statics(BigDecimal sum, BigDecimal avg, BigDecimal max, BigDecimal min, Long count) {
		super();
		this.sum = sum;
		this.avg = avg;
		this.max = max;
		this.min = min;
		this.count = count;
	}

}
