package com.n26.exception;

/**
 * @author Bharath
 *
 */
public class TransactionTimeNotValidException extends Exception {

}
