package com.n26.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.n26.exception.TransactionNotValidException;
import com.n26.exception.TransactionTimeNotValidException;
import com.n26.model.Statics;
import com.n26.model.Transaction;
import com.n26.service.TransactionServcie;

/**
 * @author Bharath
 *
 */
@RestController
@EnableScheduling
public class TransactionController {
	public static final String CLASS_NAME = TransactionController.class.getName();
	@Autowired
	TransactionServcie transactionServiceImpl;

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	/**
	 * @param transaction
	 * @return
	 * @throws TransactionTimeNotValidException
	 * @throws TransactionNotValidException
	 */
	@PostMapping("/transactions")
	public ResponseEntity<?> createTransaction(@Valid @RequestBody Transaction transaction)
			throws TransactionTimeNotValidException, TransactionNotValidException {
		log.debug(CLASS_NAME + ":Inside create transaction method");
		return transactionServiceImpl.saveNewTransaction(transaction);
	}

	/**
	 * @return Statics of Transaction
	 */
	@GetMapping("/statistics")
	@ResponseStatus(HttpStatus.OK)
	public Statics getStatics() {
		log.debug(CLASS_NAME + ":Inside calculate method");
		return transactionServiceImpl.getStatics();
	}

	/**
	 * @return Delete all transaction
	 */
	@DeleteMapping("/transactions")
	public ResponseEntity<?> deleteAll() {
		log.debug(CLASS_NAME + ":Inside deleteAll method");
		transactionServiceImpl.deleteAll();
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
	}
}
